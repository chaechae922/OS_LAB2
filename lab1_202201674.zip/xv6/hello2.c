#include "types.h"
#include "user.h"

int main(int argc, char *argv[]) {
    printf(1, "Hello world!\nMy student # is 202201674.\n");
    exit();
}
